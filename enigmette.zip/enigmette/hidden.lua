-- pour mettre en rouge ou souligné les span de classehidden
function Pandoc(doc)
  local mode = pandoc.utils.stringify(doc.meta["hidden-mode"] or "rouge")
  return doc:walk{ Span = function(el)
    if not el.classes:includes"hidden" then return end
    local cmd = mode == "souligne" and "\\underline{" or "\\textcolor{HiddenRed}{"
    -- autre couleur : "\\textcolor{HiddenBlue}{"
    local out = { pandoc.RawInline("latex", cmd) }
    for _, x in ipairs(el.content) do out[#out + 1] = x end
    out[#out + 1] = pandoc.RawInline("latex", "}")
    return out
  end }
end
