// prend un élément au hasard dans une liste
function hasard(liste) {
  return liste[Math.floor(Math.random() * liste.length)];
}

// assemble une phrase à partir des fragments
function genererPhrase() {
  const debuts = [
    "il faut que",
    "Ça fait longtemps que",
    "le dernier mardi",
    "C'est parce que",
    "C'est depuis février que",
    "Comment on va faire pour que",
  ];
  const sujets = [
    "les casseroles",
    "les enfants",
    "les chaises",
    "le glissement",
    "on",
    "tu",
    "je",
    "les infirmières",
    "la neurologue",
    "mes lunettes",
  ];
  const verbes = [
    "ont",
    "aillent",
    "amènent",
    "s'accouplent",
    "tiens pas",
    "repartent",
    "se sera vu",
    "lui diras",
    "rigolai",
    "passe",
    "aimerai comprendre",
    "trouve",
    "arroser",
    "veux",
    "peux le faire",
    "viens d'arriver",
    "étaient",
  ];
  const objets = [
    "à l'école",
    "peu",
    "tôt",
    "traumatiques",
    "troumatique",
    "de même couleur",
    "à la maison",
    "pleins d'examens",
    "ce qui bloque",
    "une cigarette",
    "tout seul",
    "les plantes",
    "à l'hôpital",
    "là",
  ];
  const ponctuations = [".", "...", "?", ":"];

// fréquence des éléments ci-dessus
  const r = Math.random();
  const que = r < 0.5 ? hasard(debuts) : "";
  const qui = r < 0.9 ? hasard(sujets) : "";
  const quoi = r < 0.8 ? hasard(verbes) : "";
  const sur = r < 0.7 ? hasard(objets) : "";
  const fin = r < 0.9 ? hasard(ponctuations) : "";

  return `${que} ${qui} ${quoi} ${sur}${fin}`.trim();
}

// ajoute une phrase dans #phrases
function insererPhrase() {
  const p = document.createElement("p");
  p.textContent = genererPhrase();
  document.querySelector("#phrases").appendChild(p);
  p.scrollIntoView({ behavior: "smooth", block: "end" });
}

// produit une nouvelle phrase toutes les 3 secondes
setInterval(insererPhrase, 3000);
insererPhrase(); // première phrase
